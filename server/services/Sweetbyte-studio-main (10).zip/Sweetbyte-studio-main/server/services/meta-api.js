// ─────────────────────────────────────────────────────────────────────────────
// Meta Marketing API — the ONE place in Studio that talks to Facebook.
//
// Everything else (routes, the boot-time connection check, later stages that
// read ads / write budgets / push creatives) goes through this file. Keeping
// all Meta calls in one module means there's a single place to handle auth,
// request signing, the API version, and error shaping.
//
// Credentials live ONLY in Render env vars (never in code, never in chat):
//   META_ACCESS_TOKEN   — long-lived system-user token (set to never expire)
//   META_APP_SECRET     — used to sign every call with an appsecret_proof
//   META_APP_ID         — Meta app id (not secret)
//   META_BUSINESS_ID    — the Green Agents business id (not secret)
//   META_API_VERSION    — graph version, e.g. 'v25.0' (override when v26 lands)
//   META_AD_ACCOUNT_ID  — OPTIONAL override. Defaults to the WDYQ test account
//                         below, which is the account the test ads live in.
//
// Money note for later stages: Meta amounts are in MINOR units (pence for GBP).
// We store budgets as whole pence in the DB; the customer screen converts to £.
// ─────────────────────────────────────────────────────────────────────────────

import crypto from 'crypto';

// The Green Agents ad account where the WDYQ test ads currently live. It isn't
// a secret (only the token + app secret are), so a sensible default lives here
// and can be overridden per-environment via META_AD_ACCOUNT_ID without a deploy.
const DEFAULT_AD_ACCOUNT_ID = '1754809155683350';

// Read env fresh each call rather than caching at import time, so a Render env
// change followed by a restart is always picked up (and tests can override).
function cfg() {
  return {
    accessToken: process.env.META_ACCESS_TOKEN || '',
    appSecret:   process.env.META_APP_SECRET || '',
    appId:       process.env.META_APP_ID || '',
    businessId:  process.env.META_BUSINESS_ID || '',
    apiVersion:  process.env.META_API_VERSION || 'v25.0',
    adAccountId: process.env.META_AD_ACCOUNT_ID || DEFAULT_AD_ACCOUNT_ID,
  };
}

// A small read-only snapshot of the non-secret config, handy for routes/logs.
// Deliberately does NOT expose the token or the app secret.
export const META = {
  get apiVersion() { return cfg().apiVersion; },
  get appId()      { return cfg().appId; },
  get businessId() { return cfg().businessId; },
  get adAccountId(){ return cfg().adAccountId; },
};

// Configured = we at least have a token to call with. Without it, every Meta
// call is pointless, so callers short-circuit on this.
export function metaConfigured() {
  return !!cfg().accessToken;
}

// appsecret_proof is Meta's tamper-check: an HMAC-SHA256 of the access token
// keyed by the app secret, sent alongside the token. Only added when the app
// secret is present (it's strongly recommended by Meta, not strictly required).
export function appsecretProof(token, appSecret) {
  if (!appSecret) return null;
  return crypto.createHmac('sha256', appSecret).update(token).digest('hex');
}

// Core request helper. Builds the Graph API URL for the given version, attaches
// the access token + appsecret_proof, sends the request, and returns parsed
// JSON. Throws an Error carrying Meta's own error message on any failure, so
// callers and the Render log get a useful line rather than a bare 400.
//
//   path   — graph path WITHOUT a leading slash, e.g. 'act_123?fields=name'
//            (or pass `params` instead of inlining a query string)
//   method — 'GET' (default), 'POST', 'DELETE'
//   params — object of query-string params (merged with token + proof)
//   body   — object sent as form-encoded body for POST (Meta expects form, not JSON)
export async function metaRequest(path, { method = 'GET', params = {}, body = null } = {}) {
  const c = cfg();
  if (!c.accessToken) throw new Error('META_ACCESS_TOKEN is not set');

  const base = `https://graph.facebook.com/${c.apiVersion}/`;
  const url = new URL(path.replace(/^\//, ''), base);

  // Auth params on every request.
  const query = { access_token: c.accessToken, ...params };
  const proof = appsecretProof(c.accessToken, c.appSecret);
  if (proof) query.appsecret_proof = proof;
  for (const [k, v] of Object.entries(query)) {
    if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
  }

  const init = { method };
  if (body && (method === 'POST' || method === 'DELETE')) {
    // Meta's Graph API takes form-encoded POST bodies. The token + proof stay
    // in the query string (where Meta reads them from regardless of method).
    const form = new URLSearchParams();
    for (const [k, v] of Object.entries(body)) {
      if (v !== undefined && v !== null) form.set(k, String(v));
    }
    init.body = form;
    init.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
  }

  let res, json;
  try {
    res = await fetch(url, init);            // Node 22 has global fetch — no dependency
  } catch (netErr) {
    throw new Error(`network error reaching Facebook: ${netErr && netErr.message ? netErr.message : netErr}`);
  }

  const text = await res.text();
  try { json = text ? JSON.parse(text) : {}; }
  catch { json = { _raw: text }; }

  // Meta signals errors either via a non-2xx status or an `error` object in the
  // body (sometimes both). Surface its message verbatim.
  if (!res.ok || (json && json.error)) {
    const e = (json && json.error) || {};
    const msg = e.message || `HTTP ${res.status}`;
    const detail = e.error_user_msg ? ` (${e.error_user_msg})` : '';
    throw new Error(`${msg}${detail}`);
  }

  return json;
}

// Fetch one ad account by id. Used by the connection test and later stages.
// Pass the bare numeric id; the `act_` prefix is added here.
export async function getAdAccount(adAccountId = cfg().adAccountId) {
  const id = String(adAccountId).replace(/^act_/, '');
  return metaRequest(`act_${id}`, {
    params: { fields: 'name,account_status,currency,amount_spent,timezone_name' },
  });
}

// List the ad accounts on the configured business. Not used by the Stage-1
// connection test (we test the specific account instead), but handy for later.
export async function listAdAccounts() {
  const c = cfg();
  if (!c.businessId) throw new Error('META_BUSINESS_ID is not set');
  return metaRequest(`${c.businessId}/owned_ad_accounts`, {
    params: { fields: 'id,name,account_status,currency', limit: 100 },
  });
}

// List the Meta Pixels in the configured business. Powers the admin pixel
// picker so the operator selects a pixel instead of typing its ID. Returns the
// raw rows ({ id, name, last_fired_time }); throws on error (the route catches).
// Only pixels the system-user token can see (i.e. in our business) come back.
export async function listPixels() {
  const c = cfg();
  if (!c.businessId) throw new Error('META_BUSINESS_ID is not set');
  const json = await metaRequest(`${c.businessId}/adspixels`, {
    params: { fields: 'id,name,last_fired_time', limit: 200 },
  });
  return Array.isArray(json.data) ? json.data : [];
}

// ── Phase-2 pre-flight: can this token actually CREATE ads? ───────────────────
// Studio only READS Facebook today. Before we build "push approved ads as paused
// drafts", we must confirm the system-user token carries write permission AND
// that a create call genuinely succeeds on the target ad account. The only
// definitive way is to create something and see if Meta accepts it — so this
// creates a PAUSED campaign shell (no ad sets, no ads, spends nothing) and then
// deletes it again. Fully self-cleaning. Returns a plain result object and never
// throws, so the route can always show a clear pass/fail verdict.
export async function checkCreatePermission(adAccountId = cfg().adAccountId) {
  const id = String(adAccountId).replace(/^act_/, '');
  const result = {
    ad_account_id: `act_${id}`,
    permissions: null,         // granted permission names, if the token exposes them
    has_ads_management: null,  // true / false / null (couldn't tell)
    account_status: null,      // 1 = active
    create_ok: false,
    delete_ok: false,
    campaign_id: null,
    error: null,
  };

  // 1) What permissions does the token carry? (read-only, best-effort)
  try {
    const perms = await metaRequest('me/permissions', { params: { limit: 200 } });
    const granted = (perms.data || []).filter(p => p.status === 'granted').map(p => p.permission);
    result.permissions = granted;
    result.has_ads_management = granted.includes('ads_management');
  } catch (e) {
    // Some system-user tokens don't expose /me/permissions — not fatal, the
    // create test below is the real proof anyway.
    result.permissions = `could not read permissions (${e.message})`;
  }

  // 2) Is the target ad account readable / active? (read-only)
  try {
    const acct = await getAdAccount(id);
    result.account_status = acct.account_status;
  } catch (e) {
    result.error = `could not read ad account act_${id}: ${e.message}`;
    return result; // no point attempting a create on an unreadable account
  }

  // 3) The definitive test: create a PAUSED campaign, then delete it.
  let campaignId = null;
  try {
    const created = await metaRequest(`act_${id}/campaigns`, {
      method: 'POST',
      body: {
        name: 'TGA Studio — create-permission test (safe to delete)',
        objective: 'OUTCOME_LEADS',
        status: 'PAUSED',
        special_ad_categories: '[]',
        // Meta now requires this true/false flag on campaign create when the
        // campaign isn't using a campaign-level budget. false = ad sets keep
        // their own budgets (no 20% sharing). Needed for the real push too.
        is_adset_budget_sharing_enabled: 'false',
      },
    });
    campaignId = created.id || null;
    result.campaign_id = campaignId;
    result.create_ok = !!campaignId;
  } catch (e) {
    result.error = e.message; // create refused — that IS the answer
    return result;
  }

  // 4) Clean up — remove the test campaign so nothing lingers in the account.
  if (campaignId) {
    try {
      await metaRequest(campaignId, { method: 'DELETE' });
      result.delete_ok = true;
    } catch (e) {
      result.delete_ok = false;
      result.error = `created OK but auto-delete failed — please delete the test campaign manually in Ads Manager (${e.message})`;
    }
  }

  return result;
}

// ── Push stage: pickers + create campaign→ad-set→ad (all PAUSED) ─────────────
//
// Studio creates the ad structure on the customer's ad account as PAUSED drafts;
// the operator does the final publish in Ads Manager. The Bulk-Import SOP's
// shell-campaign / spreadsheet dance exists only to dodge Meta's spreadsheet
// (ODAX) import bug — going API-direct we create the campaign objective straight
// (already proven by checkCreatePermission) and attach the image + lead form
// programmatically, so none of that workaround applies.

// List the Facebook Pages Studio can see, for the Page picker. Tries the pages
// this token can manage directly (/me/accounts — works WITHOUT a business id, so
// it's the reliable path when META_BUSINESS_ID isn't set), then, if a business
// id is configured, the business's owned + client pages too. Merges + de-dupes.
// Never hard-fails on a missing business id; returns whatever it can find.
export async function listPages() {
  const c = cfg();
  const out = [];
  const seen = new Set();
  const add = (arr) => {
    for (const p of (arr || [])) {
      if (p && p.id && !seen.has(p.id)) { seen.add(p.id); out.push({ id: String(p.id), name: p.name || '(unnamed page)' }); }
    }
  };

  // 1) Pages this token can manage directly — no business id required.
  try { const j = await metaRequest('me/accounts', { params: { fields: 'id,name', limit: 200 } }); add(j.data); } catch (_) {}

  // 2) If a business id is set, also pull its owned + client pages (covers pages
  //    assigned to the business but not directly to the token).
  if (c.businessId) {
    for (const edge of ['owned_pages', 'client_pages']) {
      try { const j = await metaRequest(`${c.businessId}/${edge}`, { params: { fields: 'id,name', limit: 200 } }); add(j.data); } catch (_) {}
    }
  }
  return out;
}

// Fetch a Page access token for the given page from the pages this token can
// see (/me/accounts). Used so the form list reads with the Page's own token,
// which can see restricted forms the system-user token can't. Null if not found.
// List the instant Lead forms on a Page, for the Lead-form picker. May come back
// empty if the system-user token can't read the Page's forms (e.g. it lacks the
// pages_manage_ads permission, or the form is Sharing=Restricted) — in that case
// the screen's "Enter ID manually" is used. Throws on hard error (route catches).
export async function listLeadForms(pageId) {
  const id = String(pageId || '').replace(/\D/g, '');
  if (!id) return [];
  const json = await metaRequest(`${id}/leadgen_forms`, { params: { fields: 'id,name,status', limit: 200 } });
  return Array.isArray(json.data)
    ? json.data.map(f => ({ id: String(f.id), name: f.name || '(unnamed form)', status: f.status || null }))
    : [];
}

// Upload one ad image to the ad account and return its image_hash. The creative
// references the hash (the reliable way — object_story_spec image_url is flaky).
// `imageUrl` is the public R2 URL of the final (logo-composited) ad image.
async function uploadAdImage(adAccountId, imageUrl) {
  const id = String(adAccountId).replace(/^act_/, '');
  if (!imageUrl) throw new Error('this ad has no image — click New image first');
  let bytes;
  try {
    const resp = await fetch(imageUrl);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const ab = await resp.arrayBuffer();
    bytes = Buffer.from(ab).toString('base64');
  } catch (e) {
    throw new Error(`could not read the ad image (${e && e.message ? e.message : e})`);
  }
  const json = await metaRequest(`act_${id}/adimages`, { method: 'POST', body: { bytes } });
  const images = (json && json.images) ? json.images : {};
  const first = Object.values(images)[0];
  if (!first || !first.hash) throw new Error('Facebook did not return an image hash');
  return first.hash;
}

// Normalise a customer-typed website into a valid external URL for the ad link.
// Accepts "example.co.uk", "www.example.com", "https://example.com/path" etc;
// adds https:// when no scheme is present. Returns '' for blank/unusable input.
function toExternalUrl(u) {
  const s = String(u == null ? '' : u).trim();
  if (!s) return '';
  if (/^https?:\/\//i.test(s)) return s;
  return 'https://' + s.replace(/^\/+/, '');
}

// CTA buttons Meta accepts on a LEAD-FORM creative. Attaching a lead form to any
// other button (e.g. CONTACT_US) is rejected at the creative step with
// "Invalid value field lead_gen_form_id for CTA type: …". So any CTA the ad
// generator picks that isn't on this list falls back to LEARN_MORE, which is
// always valid for lead forms — the push can never fail on the button choice.
const LEAD_FORM_CTAS = new Set([
  'SIGN_UP', 'LEARN_MORE', 'GET_QUOTE', 'SUBSCRIBE', 'APPLY_NOW', 'DOWNLOAD',
]);
function safeLeadCta(cta) {
  const t = String(cta == null ? '' : cta).toUpperCase().trim();
  return LEAD_FORM_CTAS.has(t) ? t : 'LEARN_MORE';
}

// The orchestrator the push route calls. Creates ONE Leads campaign (PAUSED) →
// ONE ad set (PAUSED, broad location+age targeting, optimised for lead-form
// submissions, tied to the Page, with the daily budget) → ONE ad per creative
// (PAUSED), each with an instant Lead form attached. Takes plain data only (no
// DB) so this module stays the single Facebook-only layer; the route reads the
// DB, calls this, and writes the results back.
//
// Never throws — returns a structured result the route can persist + show:
//   { ok, campaign_id, adset_id, error, failed_step,
//     results: [{ id, ok, ad_id, creative_id, error, step }] }
// `ok` is true if at least one ad was created. A campaign/ad-set level failure
// comes back with `error` + `failed_step` set and no ads created.
export async function pushAdsToFacebook({
  adAccountId, pageId, leadFormId, dailyBudgetPence, websiteUrl,
  countries = ['GB'], ageMin = 18, ageMax = 65, campaignName, creatives = [],
}) {
  const id = String(adAccountId || '').replace(/^act_/, '');
  const out = { ok: false, campaign_id: null, adset_id: null, error: null, failed_step: null, results: [] };

  if (!id)         { out.error = 'no ad account set'; out.failed_step = 'setup'; return out; }
  if (!pageId)     { out.error = 'no Facebook Page set'; out.failed_step = 'setup'; return out; }
  if (!leadFormId) { out.error = 'no Lead form set'; out.failed_step = 'setup'; return out; }
  if (!(Number(dailyBudgetPence) > 0)) { out.error = 'no daily budget set'; out.failed_step = 'setup'; return out; }
  // Meta requires a lead ad's creative to link to external content (the
  // advertiser's own website), never a Facebook page — so a website is required.
  const link = toExternalUrl(websiteUrl);
  if (!link) { out.error = 'no website URL set'; out.failed_step = 'setup'; return out; }

  // 1) Campaign — Leads, PAUSED. Exact call proven by checkCreatePermission.
  let campaign;
  try {
    campaign = await metaRequest(`act_${id}/campaigns`, {
      method: 'POST',
      body: {
        name: campaignName,
        objective: 'OUTCOME_LEADS',
        status: 'PAUSED',
        special_ad_categories: '[]',
        is_adset_budget_sharing_enabled: 'false',
      },
    });
  } catch (e) { out.error = e.message; out.failed_step = 'campaign'; return out; }
  out.campaign_id = campaign.id || null;

  // 2) Ad set — PAUSED, daily budget, broad targeting, lead-form optimisation.
  let adset;
  try {
    adset = await metaRequest(`act_${id}/adsets`, {
      method: 'POST',
      body: {
        name: `${campaignName} — Ad set 1`,
        campaign_id: out.campaign_id,
        status: 'PAUSED',
        daily_budget: String(Math.round(Number(dailyBudgetPence))),
        billing_event: 'IMPRESSIONS',
        optimization_goal: 'LEAD_GENERATION',
        bid_strategy: 'LOWEST_COST_WITHOUT_CAP',
        // Instant lead form opens ON the ad — required when the ad's creative
        // has a lead form attached, or Meta refuses to bind them at the ad step.
        destination_type: 'ON_AD',
        promoted_object: JSON.stringify({ page_id: String(pageId) }),
        targeting: JSON.stringify({
          geo_locations: { countries: countries.length ? countries : ['GB'] },
          age_min: ageMin, age_max: ageMax,
        }),
      },
    });
  } catch (e) {
    out.error = e.message; out.failed_step = 'adset';
    out.results = creatives.map(c => ({ id: c.id, ok: false, ad_id: null, creative_id: null, error: 'ad set was not created', step: 'adset' }));
    return out;
  }
  out.adset_id = adset.id || null;

  // 3) One ad per creative — image → creative → ad, all PAUSED. Per-ad failures
  // are recorded and the loop continues to the next ad. `link` (the advertiser's
  // website) was resolved + validated up top.
  for (const c of creatives) {
    const r = { id: c.id, ok: false, ad_id: null, creative_id: null, error: null, step: null };
    try {
      r.step = 'image';
      const imageHash = await uploadAdImage(id, c.image_url);

      r.step = 'creative';
      const oss = {
        page_id: String(pageId),
        link_data: {
          image_hash: imageHash,
          message: c.primary_text || '',
          name: c.headline || '',
          link,
          call_to_action: {
            type: safeLeadCta(c.cta),
            value: { lead_gen_form_id: String(leadFormId) },
          },
        },
      };
      const creative = await metaRequest(`act_${id}/adcreatives`, {
        method: 'POST',
        body: { name: (c.hook_label || 'Ad creative').slice(0, 80), object_story_spec: JSON.stringify(oss) },
      });
      r.creative_id = creative.id || null;

      r.step = 'ad';
      const ad = await metaRequest(`act_${id}/ads`, {
        method: 'POST',
        body: {
          name: (c.hook_label || 'Ad').slice(0, 80),
          adset_id: out.adset_id,
          creative: JSON.stringify({ creative_id: r.creative_id }),
          status: 'PAUSED',
        },
      });
      r.ad_id = ad.id || null;
      r.ok = !!r.ad_id;
    } catch (e) {
      r.error = `${r.step}: ${e && e.message ? e.message : e}`;
    }
    out.results.push(r);
  }

  out.ok = out.results.some(r => r.ok);
  return out;
}

// ── Reading ads + stats (Stage 2: read) ──────────────────────────────────────

// The date windows the admin screen offers, mapped to Meta's date_preset values.
const WINDOW_PRESETS = { '7d': 'last_7d', '30d': 'last_30d', 'lifetime': 'maximum' };

// Meta reports conversions as an `actions` array of { action_type, value }.
// A "lead" can be reported under a few different action_type names depending
// on how the event is wired, so we sum across all the lead-shaped ones.
const LEAD_ACTION_TYPES = new Set([
  'lead',
  'offsite_conversion.fb_pixel_lead',
  'onsite_conversion.lead_grouped',
  'leadgen.other',
  'offsite_conversion.lead',
]);

function sumLeadActions(actions) {
  if (!Array.isArray(actions)) return 0;
  let n = 0;
  for (const a of actions) {
    if (a && LEAD_ACTION_TYPES.has(a.action_type)) n += Number(a.value) || 0;
  }
  return n;
}

// Normalise one insights row into the four numbers the screen shows. `spend`
// from insights is a decimal string in the account's MAJOR units (pounds), so
// it's used as-is. Cost-per-lead is computed (spend ÷ leads) rather than read
// from Meta's cost_per_action_type, which is more robust across event wiring.
function statsFromInsightRow(row) {
  const spend = row ? (Number(row.spend) || 0) : 0;
  const reach = row ? (Number(row.reach) || 0) : 0;
  const leads = row ? sumLeadActions(row.actions) : 0;
  return {
    spend,
    reach,
    leads,
    cost_per_lead: leads > 0 ? spend / leads : null,
  };
}

// List the ads in an account, with enough creative detail for a simple
// image + text preview card. One page (limit 200) — the test account has a
// handful of ads; paging across more is a later concern when accounts grow.
export async function listAds(adAccountId = cfg().adAccountId) {
  const id = String(adAccountId).replace(/^act_/, '');
  const json = await metaRequest(`act_${id}/ads`, {
    params: {
      fields: 'id,name,status,effective_status,' +
              'creative{id,name,title,body,image_url,thumbnail_url},' +
              'adset{name},campaign{name,objective}',
      limit: 200,
    },
  });
  return Array.isArray(json.data) ? json.data : [];
}

// Pull insights (stats) for an account at a given level ('ad' or 'account')
// over one of the WINDOW_PRESETS. Returns the raw data rows; callers map them.
// An account with no delivery in the window returns an empty array — handled
// cleanly upstream as zeros rather than an error.
export async function getInsights(adAccountId = cfg().adAccountId, { level = 'ad', window = '30d' } = {}) {
  const id = String(adAccountId).replace(/^act_/, '');
  const datePreset = WINDOW_PRESETS[window] || WINDOW_PRESETS['30d'];
  const fields = level === 'ad'
    ? 'ad_id,spend,reach,actions'
    : 'spend,reach,actions';
  const json = await metaRequest(`act_${id}/insights`, {
    params: { level, fields, date_preset: datePreset, limit: 500 },
  });
  return Array.isArray(json.data) ? json.data : [];
}

// One-call overview the admin read screen uses: the account, account-level
// totals for the window, and a card per ad with its own stats. All Meta
// response-shape handling lives here so the route stays thin. Never throws —
// failures come back as { ok:false, error } so the UI renders a clean message.
export async function getAdsOverview({ window = '30d', adAccountId = null } = {}) {
  const win = WINDOW_PRESETS[window] ? window : '30d';
  try {
    const accountId = adAccountId || cfg().adAccountId;
    const [acct, ads, adRows, acctRows] = await Promise.all([
      getAdAccount(accountId),
      listAds(accountId),
      getInsights(accountId, { level: 'ad', window: win }),
      getInsights(accountId, { level: 'account', window: win }),
    ]);

    // Map per-ad stats by ad_id for quick lookup. Ads with no delivery in the
    // window simply won't have a row → they show zeros.
    const byAdId = new Map();
    for (const r of adRows) byAdId.set(String(r.ad_id), r);

    const cards = ads.map(ad => {
      const cr = ad.creative || {};
      const stats = statsFromInsightRow(byAdId.get(String(ad.id)));
      return {
        id: ad.id,
        name: ad.name || '(unnamed ad)',
        status: ad.status || null,
        effective_status: ad.effective_status || null,
        title: cr.title || cr.name || null,
        body: cr.body || null,
        image_url: cr.image_url || cr.thumbnail_url || null,
        campaign_name: ad.campaign ? ad.campaign.name : null,
        adset_name: ad.adset ? ad.adset.name : null,
        stats,
      };
    });

    const totals = statsFromInsightRow(acctRows[0]);

    return {
      ok: true,
      window: win,
      account: {
        id: `act_${accountId}`,
        name: acct.name || '(unnamed account)',
        currency: acct.currency || 'GBP',
        account_status: acct.account_status,
      },
      totals,
      ads: cards,
    };
  } catch (err) {
    return { ok: false, window: win, error: err && err.message ? err.message : String(err) };
  }
}

// ── Pixel stats (Meta Pixels — read-only tracking, Option A) ──────────────────
//
// The Meta Pixel measures WEBSITE events (page views, leads, purchases…). This
// pulls the pixel's own event-fire counts — anonymous aggregate counts only, no
// individual visitors or contact details (Meta never exposes those through the
// pixel). Independent of ad spend (that's the Ads screen's job).
//
// Two calls per overview:
//   • GET /{pixel_id}?fields=name,last_fired_time  → name + "last activity"
//   • GET /{pixel_id}/stats?aggregation=event&...  → counts per event type
// The /stats edge's response shape has historically varied across Graph
// versions, so the parser below tolerates a couple of shapes and never throws —
// failures come back as { ok:false } so the UI renders a clean message.

// Map Meta's standard event names to plain-English labels for the screens.
const PIXEL_EVENT_LABELS = {
  PageView: 'Page views',
  ViewContent: 'View content',
  Search: 'Searches',
  AddToCart: 'Add to cart',
  AddToWishlist: 'Add to wishlist',
  InitiateCheckout: 'Checkout started',
  AddPaymentInfo: 'Payment info added',
  Purchase: 'Purchases',
  Lead: 'Leads',
  CompleteRegistration: 'Registrations',
  Contact: 'Contacts',
  SubmitApplication: 'Applications',
  Subscribe: 'Subscriptions',
  Schedule: 'Bookings',
  StartTrial: 'Trials started',
  FindLocation: 'Location lookups',
  CustomizeProduct: 'Product customisations',
  Donate: 'Donations',
};
function friendlyEventLabel(type) {
  if (PIXEL_EVENT_LABELS[type]) return PIXEL_EVENT_LABELS[type];
  // Humanise an unknown CamelCase / custom event name: "MyCustomEvent" → "My custom event".
  const spaced = String(type).replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').trim();
  return spaced ? spaced.charAt(0).toUpperCase() + spaced.slice(1).toLowerCase() : String(type);
}

// Window → a start_time (unix seconds). The /stats edge uses start_time/end_time,
// not Meta's date_preset. 'lifetime' just reaches back far (the edge has its own
// retention cap; we don't need to be exact).
function pixelWindowStart(window) {
  const now = Math.floor(Date.now() / 1000);
  const day = 86400;
  if (window === '7d') return now - 7 * day;
  if (window === 'lifetime') return now - 730 * day;
  return now - 30 * day; // default 30d
}

// Normalise the /stats response into a Map of event_type → total count, summed
// across whatever time buckets Meta returns. Tolerates the two shapes we've
// seen: rows carrying a `data: [{ value, count }]` array, or a `value` object
// that's a plain { EventName: count } map.
function sumPixelEvents(statsJson) {
  const totals = new Map();
  const rows = (statsJson && Array.isArray(statsJson.data)) ? statsJson.data : [];
  const bump = (type, n) => {
    if (!type) return;
    const add = Number(n) || 0;
    totals.set(type, (totals.get(type) || 0) + add);
  };
  for (const row of rows) {
    if (row && Array.isArray(row.data)) {
      for (const d of row.data) bump(d && d.value, d && d.count);
    } else if (row && row.value && typeof row.value === 'object') {
      for (const [type, count] of Object.entries(row.value)) bump(type, count);
    }
  }
  return totals;
}

// Build a per-day activity series for the history graph, from the same /stats
// rows. Each row is a time bucket carrying a timestamp + its event counts; we
// floor the timestamp to a calendar day (UTC) and sum every event in that row
// into that day. Defensive: rows without a usable timestamp are skipped, so a
// shape we don't expect yields an empty series (the chart hides gracefully)
// rather than throwing.
function buildDailySeries(statsJson) {
  const byDay = new Map(); // 'YYYY-MM-DD' -> total events that day
  const rows = (statsJson && Array.isArray(statsJson.data)) ? statsJson.data : [];
  for (const row of rows) {
    const ts = Number(row && (row.start_time != null ? row.start_time : row.timestamp));
    if (!ts) continue;
    const d = new Date(ts * 1000);
    if (Number.isNaN(d.getTime())) continue;
    const key = d.toISOString().slice(0, 10);
    let rowTotal = 0;
    if (Array.isArray(row.data)) {
      for (const e of row.data) rowTotal += Number(e && e.count) || 0;
    } else if (row.value && typeof row.value === 'object') {
      for (const v of Object.values(row.value)) rowTotal += Number(v) || 0;
    }
    byDay.set(key, (byDay.get(key) || 0) + rowTotal);
  }
  return [...byDay.entries()]
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => a.date.localeCompare(b.date));
}
export async function getPixelStats({ pixelId, window = '30d' } = {}) {
  const win = ['7d', '30d', 'lifetime'].includes(window) ? window : '30d';
  const id = String(pixelId || '').replace(/\D/g, '');
  if (!id) return { ok: false, window: win, error: 'No pixel ID set for this customer yet.' };

  try {
    const start = pixelWindowStart(win);
    const end = Math.floor(Date.now() / 1000);

    const [meta, stats] = await Promise.all([
      metaRequest(`${id}`, { params: { fields: 'name,last_fired_time' } }),
      metaRequest(`${id}/stats`, { params: { aggregation: 'event', start_time: start, end_time: end } }),
    ]);

    const totals = sumPixelEvents(stats);
    const events = [...totals.entries()]
      .map(([type, count]) => ({ type, label: friendlyEventLabel(type), count }))
      .sort((a, b) => b.count - a.count);
    const total_events = events.reduce((n, e) => n + e.count, 0);

    // Status from last_fired_time: fired in last 24h → active; older → quiet;
    // never fired (or unknown) → no_data.
    let status = 'no_data';
    const lf = meta && meta.last_fired_time ? Date.parse(meta.last_fired_time) : NaN;
    if (!Number.isNaN(lf)) {
      status = (Date.now() - lf) <= 24 * 3600 * 1000 ? 'active' : 'quiet';
    }

    return {
      ok: true,
      window: win,
      pixel: { id, name: (meta && meta.name) || null, last_fired_time: (meta && meta.last_fired_time) || null },
      status,
      total_events,
      events,
      series: buildDailySeries(stats),
    };
  } catch (err) {
    return { ok: false, window: win, error: err && err.message ? err.message : String(err) };
  }
}

// The connection test the boot log and /connection-status both use. It fetches
// the specific ad account we'll actually run ads in — proving in one call that
// (a) the token works, (b) it has ads access, and (c) it can see that account.
// Returns a plain result object; never throws (failures come back as ok:false).
export async function testConnection() {
  try {
    const acct = await getAdAccount();
    return {
      ok: true,
      account: {
        id: `act_${cfg().adAccountId}`,
        name: acct.name || '(unnamed account)',
        account_status: acct.account_status,
        currency: acct.currency || null,
      },
    };
  } catch (err) {
    return { ok: false, error: err && err.message ? err.message : String(err) };
  }
}
